package Test::UserAgent::Transaction;
use Moo;
has result => (
    is => 'ro'
);

1;
